
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export function WorkoutsScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Treinos para hoje</Text>
      <View style={styles.card}><Text style={styles.cardTitle}>HIIT - 15 min</Text><Text style={styles.cardText}>Circuito para queima de gordura</Text></View>
      <View style={styles.card}><Text style={styles.cardTitle}>Força - 30 min</Text><Text style={styles.cardText}>Exercícios para membros inferiores</Text></View>
      <View style={styles.card}><Text style={styles.cardTitle}>Core - 12 min</Text><Text style={styles.cardText}>Abdominais e prancha</Text></View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ flex:1, backgroundColor:'#000', padding:16 },
  heading:{ color:'#fff', fontSize:22, fontWeight:'bold', marginBottom:12 },
  card:{ backgroundColor:'#111', padding:14, borderRadius:12, marginBottom:10 },
  cardTitle:{ color:'#1DB954', fontWeight:'bold', fontSize:16 },
  cardText:{ color:'#ccc', marginTop:6 }
});
