
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export function NutritionScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Planos alimentares</Text>
      <View style={styles.card}><Text style={styles.cardTitle}>Plano para perda de gordura</Text><Text style={styles.cardText}>Refeições simples e econômicas</Text></View>
      <View style={styles.card}><Text style={styles.cardTitle}>Plano para hipertrofia</Text><Text style={styles.cardText}>Foco em proteínas e calorias</Text></View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ flex:1, backgroundColor:'#000', padding:16 },
  heading:{ color:'#fff', fontSize:22, fontWeight:'bold', marginBottom:12 },
  card:{ backgroundColor:'#111', padding:14, borderRadius:12, marginBottom:10 },
  cardTitle:{ color:'#1DB954', fontWeight:'bold', fontSize:16 },
  cardText:{ color:'#ccc', marginTop:6 }
});
