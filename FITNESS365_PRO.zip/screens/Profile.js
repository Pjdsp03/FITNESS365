
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Seu Perfil</Text>
      <Text style={styles.text}>Progresso, metas e configurações aparecem aqui.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{ flex:1, backgroundColor:'#000', padding:16 },
  title:{ color:'#fff', fontSize:22, fontWeight:'bold', marginBottom:10 },
  text:{ color:'#ccc' }
});
