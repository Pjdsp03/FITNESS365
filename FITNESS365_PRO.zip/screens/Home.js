
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bem-vindo ao FITNESS365</Text>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Workouts')}>
        <Text style={styles.buttonText}>Treinos</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Nutrition')}>
        <Text style={styles.buttonText}>Nutrição</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Profile')}>
        <Text style={styles.buttonText}>Perfil</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, backgroundColor:'#000', alignItems:'center', justifyContent:'center', padding:20 },
  title: { color:'#fff', fontSize:26, marginBottom:20, fontWeight:'bold' },
  button: { backgroundColor:'#1DB954', padding:14, borderRadius:10, width:'80%', alignItems:'center', marginTop:10 },
  buttonText: { color:'#fff', fontSize:18, fontWeight:'600' }
});
